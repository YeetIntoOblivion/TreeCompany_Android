The Spanish Inquisition presents: Integratieproject: City of Ideas Now In Android:
--------------------------------------------------------------------------------------------------------------------
Mère Superieure: @YeetIntoOblvious (aka the Code Knight) Hij zal pull requests naar de master mogen doen die Edwin onderhoudt.

Master branch is off limits, all edits must be made in seperate branches

Every pull request is to the dev.
Every update will be visible on #github-android. on the official The Spanish Inquisition discord.
